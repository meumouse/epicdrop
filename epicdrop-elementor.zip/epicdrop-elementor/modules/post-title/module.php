<?php
namespace EpicDropElementor\Modules\PostTitle;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
use EpicDropElementor\Base\Module_Base;

class Module extends Module_Base {

    public function get_widgets() {
        return [
            'Post_Title'
        ];
    }

    public function get_name() {
        return 'ed-post-title';
    }
}
