<?php
namespace EpicDropElementor\Modules\PostInfo;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
use EpicDropElementor\Base\Module_Base;

class Module extends Module_Base {

    public function get_widgets() {
        return [
            'Post_Info'
        ];
    }

    public function get_name() {
        return 'ed-post-info';
    }
}
