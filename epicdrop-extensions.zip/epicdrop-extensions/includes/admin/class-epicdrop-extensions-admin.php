<?php
/**
 * EpicDrop Admin
 *
 * @class    EpicDrop_Extensions_Admin
 * @author   MeuMouse.com
 * @category Admin
 * @package  EpicDropExtensions/Admin
 * @version  1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * EpicDrop_Extensions_Admin class.
 */
class EpicDrop_Extensions_Admin {

    /**
     * Constructor.
     */
    public function __construct() {
        add_action( 'init', array( $this, 'includes' ) );
        add_action( 'admin_init', array( $this, 'buffer' ), 1 );
        add_action( 'admin_enqueue_scripts', array( $this, 'admin_styles' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );

    }

    /**
     * Output buffering allows admin screens to make redirects later on.
     */
    public function buffer() {
        ob_start();
    }

    /**
     * Include any classes we need within admin.
     */
    public function includes() {
        include_once dirname( __FILE__ ) . '/epicdrop-meta-box-functions.php';
        include_once dirname( __FILE__ ) . '/class-epicdrop-admin-meta-boxes.php';
    }

    /**
     * Enqueue style.
     */
    public function admin_styles() {
        $version = EpicDrop_Extensions()->version;
        wp_register_style( 'epicdrop-admin-meta-boxes', plugins_url( '/assets/css/admin-meta-boxes.css', EPICDROP_PLUGIN_FILE ), array(), $version );
        wp_enqueue_style( 'epicdrop-admin-meta-boxes' );

    }

    /**
     * Enqueue scripts.
     */
    public function admin_scripts() {
        $version = EpicDrop_Extensions()->version;
        wp_register_script( 'epicdrop-admin-meta-boxes', plugins_url( '/assets/js/admin-meta-boxes.js', EPICDROP_PLUGIN_FILE ), array( 'jquery', 'jquery-ui-datepicker', 'jquery-ui-sortable'), $version );
        wp_enqueue_script( 'epicdrop-admin-meta-boxes' );
    }

    /**
     * Include admin files conditionally.
     */
    public function conditional_includes() {
        if ( ! $screen = get_current_screen() ) {
            return;
        }
    }
}

return new EpicDrop_Extensions_Admin();