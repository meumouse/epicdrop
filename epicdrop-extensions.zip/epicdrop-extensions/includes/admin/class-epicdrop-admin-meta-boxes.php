<?php
/**
 * EpicDrop Meta Boxes
 *
 * Sets up the write panels used by products and orders (custom post types).
 *
 * @author      MeuMouse.com
 * @category    Admin
 * @package     EpicDrop/Admin/Meta Boxes
 * @version     1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * EpicDrop_Admin_Meta_Boxes.
 */
class EpicDrop_Admin_Meta_Boxes {

    /**
     * Is meta boxes saved once?
     *
     * @var boolean
     */
    private static $saved_meta_boxes = false;

    /**
     * Meta box error messages.
     *
     * @var array
     */
    public static $meta_box_errors = array();

    /**
     * Constructor.
     */
    public function __construct() {
        add_action( 'add_meta_boxes', array( $this, 'add_meta_boxes' ), 30 );
        add_action( 'save_post', array( $this, 'save_meta_boxes' ), 1, 2 );

        add_action( 'epicdrop_process_coming_soon_meta', 'EpicDrop_Meta_Box_Coming_Soon::save', 10, 2 );
        add_action( 'epicdrop_process_docs_meta', 'EpicDrop_Meta_Box_Docs::save', 20, 2 );
        add_action( 'epicdrop_process_page_meta', 'EpicDrop_Meta_Box_Page::save', 20, 2 );

        add_action( 'epicdrop_process_cover_image_meta', 'EpicDrop_Meta_Box_Cover_Image::save', 20, 2 );

        // Error handling (for showing errors from meta boxes on next page load).
        add_action( 'admin_notices', array( $this, 'output_errors' ) );
        add_action( 'shutdown', array( $this, 'save_errors' ) );
    }

    /**
     * Add an error message.
     *
     * @param string $text
     */
    public static function add_error( $text ) {
        self::$meta_box_errors[] = $text;
    }

    /**
     * Save errors to an option.
     */
    public function save_errors() {
        update_option( 'epicdrop_meta_box_errors', self::$meta_box_errors );
    }

    /**
     * Show any stored error messages.
     */
    public function output_errors() {
        $errors = array_filter( (array) get_option( 'epicdrop_meta_box_errors' ) );

        if ( ! empty( $errors ) ) {

            echo '<div id="epicdrop_errors" class="error notice is-dismissible">';

            foreach ( $errors as $error ) {
                echo '<p>' . wp_kses_post( $error ) . '</p>';
            }

            echo '</div>';

            // Clear
            delete_option( 'epicdrop_meta_box_errors' );
        }
    }

    /**
     * Add epicdrop Meta boxes.
     */
    public function add_meta_boxes() {
        global $post;

        $screen    = get_current_screen();
        $screen_id = $screen ? $screen->id : '';

        if ( $post->ID == get_option( 'page_for_posts' ) && empty( $post->post_content ) ) {
            return;
        }

        add_meta_box( 'ed-post-featured-icon', esc_html__( 'EpicDrop Docs Options', 'epicdrop-extensions' ), 'EpicDrop_Meta_Box_Docs::output', 'docs', 'side', 'low' );

        add_meta_box( 'ed-page-options', esc_html__( 'Page Options', 'epicdrop-extensions' ), 'EpicDrop_Meta_Box_Page::output', 'page', 'side', 'low' );

        add_meta_box( 'ed-cover-image', esc_html__( 'Cover Image', 'epicdrop-extensions' ), 'EpicDrop_Meta_Box_Cover_Image::output', self::cover_image_enabled_post_types(), 'side', 'high' );

        $template_file  = get_post_meta( $post->ID, '_wp_page_template', true );


        if ( $template_file === 'template-comingsoon.php' ) {
            add_meta_box( 'ed-coming-soon-options', esc_html__( 'Coming Soon Options', 'epicdrop-extensions' ), 'EpicDrop_Meta_Box_Coming_Soon::output', 'page', 'normal', 'high' );
        }
        
    }


    /**
     * Cover Image Enabled Post Types.
     *
     * @param string $text
     */
    public function cover_image_enabled_post_types() {
        $post_types = [ 'post', 'jetpack-portfolio' ];
        return apply_filters( 'ar_cover_image_enabled_post_types', $post_types );
    }

    /**
     * Check if we're saving, the trigger an action based on the post type.
     *
     * @param  int    $post_id
     * @param  object $post
     */
    public function save_meta_boxes( $post_id, $post ) {
        global $post;

        // $post_id and $post are required
        if ( empty( $post_id ) || empty( $post ) || self::$saved_meta_boxes ) {
            return;
        }

        // Dont' save meta boxes for revisions or autosaves
        if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || is_int( wp_is_post_revision( $post ) ) || is_int( wp_is_post_autosave( $post ) ) ) {
            return;
        }

        // Check the nonce
        if ( empty( $_POST['epicdrop_meta_nonce'] ) || ! wp_verify_nonce( $_POST['epicdrop_meta_nonce'], 'epicdrop_save_data' ) ) {
            return;
        }

        // Check the post being saved == the $post_id to prevent triggering this call for other save_post events
        if ( empty( $_POST['post_ID'] ) || $_POST['post_ID'] != $post_id ) {
            return;
        }

        // Check user has permission to edit
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        // We need this save event to run once to avoid potential endless loops. This would have been perfect:
        // remove_action( current_filter(), __METHOD__ );
        // But cannot be used due to https://github.com/woocommerce/woocommerce/issues/6485
        // When that is patched in core we can use the above. For now:
        self::$saved_meta_boxes = true;


        $template_file = get_post_meta( $post->ID, '_wp_page_template', true );

        // Check the post type

        if ( in_array( $post->post_type, array( 'docs', 'page' ) ) ) {
            do_action( 'epicdrop_process_' . $post->post_type . '_meta', $post_id, $post );
        }

        if ( in_array( $post->post_type, self::cover_image_enabled_post_types() ) ) {
            do_action( 'epicdrop_process_cover_image_meta', $post_id, $post );
        }

        if (  $template_file === 'template-comingsoon.php' )  {
            do_action( 'epicdrop_process_coming_soon_meta', $post_id, $post );
        }
    }
}

new EpicDrop_Admin_Meta_Boxes();
