<?php
namespace EpicDropElementor\Modules\ImageGrid\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use EpicDropElementor\Base\Base_Widget;
use EpicDropElementor\Modules\ImageGrid\Skins;
use Elementor\Icons_Manager;
use Elementor\Plugin;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes;
use Elementor\Utils;



class Image_Grid extends Base_Widget {

	public function get_name() {
        return 'ed-image-grid';
    }

    public function get_title() {
        return esc_html__( 'Image Grid', 'epicdrop-elementor' );
    }

    public function get_icon() {
        return 'eicon-gallery-justified';
    }

    protected $_has_template_content = false;

	protected function register_skins() {
		$this->add_skin( new Skins\Skin_Grid_1( $this ) );
		$this->add_skin( new Skins\Skin_Grid_2( $this ) );
    }

	protected function register_controls () {
		$this->start_controls_section( 'section_grid', [ 'label' => __( 'Grid Column 1 Settings', 'epicdrop-elementor' ) ] );

		$this->add_responsive_control(
            'column',
            [
                'type' => Controls_Manager::SELECT,
                'label' => __( 'Column 1', 'epicdrop-elementor' ),
                'options' => [
                    '' => __( 'Default', 'epicdrop-elementor' ),
                    '1' => __( '1', 'epicdrop-elementor' ),
                    '2' => __( '2', 'epicdrop-elementor' ),
                    '3' => __( '3', 'epicdrop-elementor' ),
                    '4' => __( '4', 'epicdrop-elementor' ),
                    '5' => __( '5', 'epicdrop-elementor' ),
                    '6' => __( '6', 'epicdrop-elementor' ),
                ],
                'frontend_available' => true,
                'condition' => [
                    '_skin' => 'grid-style-2'
                ]
            ]
        );

        $this->add_responsive_control(
            'column_2',
            [
                'type' => Controls_Manager::SELECT,
                'label' => __( 'Column 2', 'epicdrop-elementor' ),
                'options' => [
                    '' => __( 'Default', 'epicdrop-elementor' ),
                    '1' => __( '1', 'epicdrop-elementor' ),
                    '2' => __( '2', 'epicdrop-elementor' ),
                    '3' => __( '3', 'epicdrop-elementor' ),
                    '4' => __( '4', 'epicdrop-elementor' ),
                    '5' => __( '5', 'epicdrop-elementor' ),
                    '6' => __( '6', 'epicdrop-elementor' ),
                ],
                'frontend_available' => true,
                'condition' => [
                    '_skin' => 'grid-style-2'
                ]
            ]
        );

		$repeater = new Repeater();

        $repeater->add_control(
            'title', [
                'label'       => esc_html__( 'Title', 'epicdrop-elementor' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'dynamic'     => [
                    'active' => true,
                ],
                'default'     => esc_html__( 'Title', 'epicdrop-elementor' ),
                'placeholder' => esc_html__( ' Title', 'epicdrop-elementor' ),
            ]
        );

        $repeater->add_control(
            'content', [
                'label'       => esc_html__( 'Content', 'epicdrop-elementor' ),
                'type'        => Controls_Manager::WYSIWYG,
                'label_block' => true,
                'dynamic'     => [
                    'active' => true,
                ],
                'default'     => esc_html__( 'Find aute irure dolor in reprehend in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'epicdrop-elementor' ),
                'placeholder' => esc_html__( 'Image Grid Content', 'epicdrop-elementor' ),
            ]
        );

        $repeater->add_control(
            'image',
            [
                'label' => __( 'Choose Image', 'epicdrop-elementor' ),
                'type' => Controls_Manager::MEDIA,
                'dynamic' => [
                    'active' => true,
                ],
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'content_settings', [
                'type'      => Controls_Manager::REPEATER,
                'fields'    => $repeater->get_controls(),
                'default'   => [
                    [
                        'title'    => esc_html__( 'SEO Website Audit', 'epicdrop-elementor' ),
                    ],
                    [
                        'title'    => esc_html__( 'Email Marketing', 'epicdrop-elementor' ),
                    ],
                ],
                'title_field' => '{{{ title }}}',
            ]
        );

        $repeater_2 = new Repeater();

        $repeater_2->add_control(
            'title_2', [
                'label'       => esc_html__( 'Title', 'epicdrop-elementor' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'dynamic'     => [
                    'active' => true,
                ],
                'placeholder' => esc_html__( 'Title', 'epicdrop-elementor' ),
            ]
        );

        $repeater_2->add_control(
            'content_2', [
                'label'       => esc_html__( 'Content', 'epicdrop-elementor' ),
                'type'        => Controls_Manager::WYSIWYG,
                'label_block' => true,
                'dynamic'     => [
                    'active' => true,
                ],
                'default'     => esc_html__( 'Find aute irure dolor in reprehend in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'epicdrop-elementor' ),
                'placeholder' => esc_html__( 'Image Grid Content', 'epicdrop-elementor' ),
            ]
        );

        $repeater_2->add_control(
            'image_2',
            [
                'label' => __( 'Choose Image', 'epicdrop-elementor' ),
                'type' => Controls_Manager::MEDIA,
                'dynamic' => [
                    'active' => true,
                ],
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'content_settings_2', [
                'type'      => Controls_Manager::REPEATER,
                'fields'    => $repeater_2->get_controls(),
                'default'   => [
                    [
                        'title_2'    => esc_html__( 'Content Marketing', 'epicdrop-elementor' ),
                    ],
                    [
                        'title_2'    => esc_html__( 'Link Building', 'epicdrop-elementor' ),
                    ],
                ],
                'title_field' => '{{{ title_2 }}}',
            ]
        );
		$this->end_controls_section();
	}
}

