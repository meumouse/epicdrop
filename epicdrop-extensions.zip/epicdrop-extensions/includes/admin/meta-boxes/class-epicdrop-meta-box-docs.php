<?php
/**
 * Docs Icons
 *
 * Display the docs meta box.
 *
 * @author      MadrasThemes
 * @category    Admin
 * @package     EpicDrop/Admin/Meta Boxes
 * @version     2.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * EpicDrop_Meta_Box_Docs Class.
 */
class EpicDrop_Meta_Box_Docs {

    /**
     * Output the metabox.
     *
     * @param WP_Post $post
     */
    public static function output( $post ) {
        global $thepostid;
        $thepostid      = $post->ID;

        wp_nonce_field( 'epicdrop_save_data', 'epicdrop_meta_nonce' );

        self::output_docs( $post );
    }

    private static function output_docs( $post ) {

        if ( ! function_exists( 'epicdrop_get_docs_meta' ) ) {
            return;
        }

        $wedocs = epicdrop_get_docs_meta();

        ?><div class="epicdrop-options"><?php

            epicdrop_wp_text_input( array(
                'id'            => '_wedocs_post_featured_icon',
                'name'          => '_wedocs[post_featured_icon]',
                'label'         => esc_html__( 'Featured Icon', 'epicdrop-extensions' ),
                'value'         => isset( $wedocs['post_featured_icon'] ) ? $wedocs['post_featured_icon'] : '',
            ) );

            epicdrop_wp_select( array(
                'label'         => esc_html__( 'Featured Icon Background', 'epicdrop-extensions' ),
                'name'          => '_wedocs[post_featured_icon_bg]',
                'id'            => '_wedocs_post_featured_icon_bg',
                'type'          => 'select',
                'options'       => array(
                    'primary'       => esc_html__( 'Primary', 'epicdrop-extensions'),
                    'secondary'     => esc_html__( 'Secondary', 'epicdrop-extensions'), 
                    'success'       => esc_html__( 'Success', 'epicdrop-extensions'),
                    'danger'        => esc_html__( 'Danger', 'epicdrop-extensions'),
                    'warning'       => esc_html__( 'Warning', 'epicdrop-extensions'),
                    'info'          => esc_html__( 'Info', 'epicdrop-extensions'),
                    'light'         => esc_html__( 'Light', 'epicdrop-extensions'),
                    'dark'          => esc_html__( 'Dark', 'epicdrop-extensions'),
                    'primary-desat' => esc_html__( 'Primary Desat', 'epicdrop-extensions'),
                ),
                'value'         => isset( $wedocs['post_featured_icon_bg'] ) ? $wedocs['post_featured_icon_bg'] : '',
            ) );

        ?></div><?php
    }
    

    /**
     * Save meta box data.
     *
     * @param int     $post_id
     * @param WP_Post $post
     */


    public static function save( $post_id, $post ) {
        if ( isset( $_POST['_wedocs'] ) ) {
            $clean_docs_options = epicdrop_clean( $_POST['_wedocs'] );
            update_post_meta( $post_id, '_docs_options',  serialize( $clean_docs_options ) );
        }   
    }
}
