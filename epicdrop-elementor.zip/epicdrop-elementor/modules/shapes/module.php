<?php

namespace EpicDropElementor\Modules\Shapes;

use EpicDropElementor\Base\Module_Base;
use Elementor\Controls_Manager;
use Elementor\Plugin;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

class Module extends Module_Base {

     public function get_widgets() {
        return [
            'Shapes',
        ];
    }

    public function __construct() {
        parent::__construct();

        $this->add_actions();
    }

    public function get_name() {
        return 'ar-shapes';
    }

    public function add_actions() {
        add_filter( 'elementor/shapes/additional_shapes', [ $this, 'shape_options' ] );
    }

    public function shape_options( $additional_shapes ) {

        $additional_shapes ['epicdrop-slant-bottom-right'] =[
            'title'        => _x( 'epicdrop - Slant-bottom-right', 'Shapes', 'epicdrop-elementor' ),
            'has_negative' => false,
            'has_flip'     => false,
            'height_only'  => false,
            'url'          => get_template_directory_uri() . '/assets/img/shapes/slant/slant-bottom-right.svg',
            'path'         => get_stylesheet_directory() . '/assets/img/shapes/slant/slant-bottom-right.svg',
        ];

        $additional_shapes ['epicdrop-slant-bottom-left'] =[
            'title'        => _x( 'epicdrop - Slant-bottom-left', 'Shapes', 'epicdrop-elementor' ),
            'has_negative' => false,
            'has_flip'     => false,
            'height_only'  => false,
            'url'          => get_template_directory_uri() . '/assets/img/shapes/slant/slant-bottom-left.svg',
            'path'         => get_stylesheet_directory() . '/assets/img/shapes/slant/slant-bottom-left.svg',
        ];

        $additional_shapes ['epicdrop-slant-top-right'] =[
            'title'        => _x( 'epicdrop - Slant-top-right', 'Shapes', 'epicdrop-elementor' ),
            'has_negative' => false,
            'has_flip'     => false,
            'height_only'  => false,
            'url'          => get_template_directory_uri() . '/assets/img/shapes/slant/slant-top-right.svg',
            'path'         => get_stylesheet_directory() . '/assets/img/shapes/slant/slant-top-right.svg',
        ];

        $additional_shapes ['epicdrop-slant-top-left'] =[
            'title'        => _x( 'epicdrop - Slant-top-left', 'Shapes', 'epicdrop-elementor' ),
            'has_negative' => false,
            'has_flip'     => false,
            'height_only'  => false,
            'url'          => get_template_directory_uri() . '/assets/img/shapes/slant/slant-top-left.svg',
            'path'         => get_stylesheet_directory() . '/assets/img/shapes/slant/slant-top-left.svg',
        ];

        $additional_shapes ['epicdrop-curve-bottom-center'] =[
            'title'        => _x( 'epicdrop - Curve-bottom-center', 'Shapes', 'epicdrop-elementor' ),
            'has_negative' => false,
            'has_flip'     => false,
            'height_only'  => false,
            'url'          => get_template_directory_uri() . '/assets/img/shapes/curves/curve-bottom-center.svg',
            'path'         => get_stylesheet_directory() . '/assets/img/shapes/curves/curve-bottom-center.svg',
        ];

        $additional_shapes ['epicdrop-curve-top-center'] =[
            'title'        => _x( 'epicdrop - Curve-top-center', 'Shapes', 'epicdrop-elementor' ),
            'has_negative' => false,
            'has_flip'     => false,
            'height_only'  => false,
            'url'          => get_template_directory_uri() . '/assets/img/shapes/curves/curve-top-center.svg',
            'path'         => get_stylesheet_directory() . '/assets/img/shapes/curves/curve-top-center.svg',
        ];

        $additional_shapes ['epicdrop-curve-bottom-right'] =[
            'title'        => _x( 'epicdrop - Curve-bottom-right', 'Shapes', 'epicdrop-elementor' ),
            'has_negative' => false,
            'has_flip'     => false,
            'height_only'  => false,
            'url'          => get_template_directory_uri() . '/assets/img/shapes/curves/curve-bottom-right.svg',
            'path'         => get_stylesheet_directory() . '/assets/img/shapes/curves/curve-bottom-right.svg',
        ];

        $additional_shapes ['epicdrop-curve-bottom-left'] =[
            'title'        => _x( 'epicdrop - Curve-bottom-left', 'Shapes', 'epicdrop-elementor' ),
            'has_negative' => false,
            'has_flip'     => false,
            'height_only'  => false,
            'url'          => get_template_directory_uri() . '/assets/img/shapes/curves/curve-bottom-left.svg',
            'path'         => get_stylesheet_directory() . '/assets/img/shapes/curves/curve-bottom-left.svg',
        ];

        $additional_shapes ['epicdrop-curve-top-right'] =[
            'title'        => _x( 'epicdrop - Curve-top-right', 'Shapes', 'epicdrop-elementor' ),
            'has_negative' => false,
            'has_flip'     => false,
            'height_only'  => false,
            'url'          => get_template_directory_uri() . '/assets/img/shapes/curves/curve-top-right.svg',
            'path'         => get_stylesheet_directory() . '/assets/img/shapes/curves/curve-top-right.svg',
        ];

        $additional_shapes ['epicdrop-curve-top-left'] =[
            'title'        => _x( 'epicdrop - Curve-top-left', 'Shapes', 'epicdrop-elementor' ),
            'has_negative' => false,
            'has_flip'     => false,
            'height_only'  => false,
            'url'          => get_template_directory_uri() . '/assets/img/shapes/curves/curve-top-left.svg',
            'path'         => get_stylesheet_directory() . '/assets/img/shapes/curves/curve-top-left.svg',
        ];


        $additional_shapes ['epicdrop-curve-right'] =[
            'title'        => _x( 'epicdrop - Curve Right', 'Shapes', 'epicdrop-elementor' ),
            'has_negative' => false,
            'has_flip'     => false,
            'height_only'  => false,
            'url'          => get_template_directory_uri() . '/assets/img/shapes/curves/curve-right.svg',
            'path'         => get_stylesheet_directory() . '/assets/img/shapes/curves/curve-right.svg',
        ];

        $additional_shapes ['epicdrop-curve-left'] =[
            'title'        => _x( 'epicdrop - Curve Left', 'Shapes', 'epicdrop-elementor' ),
            'has_negative' => false,
            'has_flip'     => false,
            'height_only'  => false,
            'url'          => get_template_directory_uri() . '/assets/img/shapes/curves/curve-left.svg',
            'path'         => get_stylesheet_directory() . '/assets/img/shapes/curves/curve-left.svg',
        ];

        return $additional_shapes;
    }
}