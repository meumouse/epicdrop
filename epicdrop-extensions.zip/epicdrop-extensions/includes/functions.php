<?php

// Static Content Jetpack Share Remove
if ( ! function_exists( 'epicdrop_mas_static_content_jetpack_sharing_remove_filters' ) ) {
    function epicdrop_mas_static_content_jetpack_sharing_remove_filters() {
        if( function_exists( 'sharing_display' ) ) {
            remove_filter( 'the_content', 'sharing_display', 19 );
        }
    }
}

add_action( 'mas_static_content_before_shortcode_content', 'epicdrop_mas_static_content_jetpack_sharing_remove_filters' );

if ( ! function_exists( 'epicdrop_mas_static_content_jetpack_sharing_add_filters' ) ) {
    function epicdrop_mas_static_content_jetpack_sharing_add_filters() {
        if( function_exists( 'sharing_display' ) ) {
            add_filter( 'the_content', 'sharing_display', 19 );
        }
    }
}

add_action( 'mas_static_content_after_shortcode_content', 'epicdrop_mas_static_content_jetpack_sharing_add_filters' );

// Jetpack
if ( ! function_exists( 'epicdrop_jetpack_sharing_remove_filters' ) ) {
    function epicdrop_jetpack_sharing_remove_filters() {
        if( function_exists( 'sharing_display' ) ) {
            remove_filter( 'the_content', 'sharing_display', 19 );
            remove_filter( 'the_excerpt', 'sharing_display', 19 );
        }
    }
}

add_action( 'epicdrop_single_post_before', 'epicdrop_jetpack_sharing_remove_filters', 5 );
add_action( 'woocommerce_after_single_product_summary', 'epicdrop_jetpack_sharing_remove_filters', 5 );



// Register widgets.
if ( ! function_exists ( 'epicdrop_widgets_register' )  ) {

    function epicdrop_widgets_register() {

        if ( class_exists( 'EpicDrop' ) ) {
            include_once AROUND_EXTENSIONS_DIR . '/includes/widgets/class-epicdrop-random-posts-widget.php';
            register_widget( 'EpicDrop_Random_Posts_Widget' );
        }
    }
}

add_action( 'widgets_init', 'epicdrop_widgets_register' );



add_action( 'init', 'create_ingredients_nonhierarchical_taxonomy', 0 );
 
if ( ! function_exists ('create_ingredients_nonhierarchical_taxonomy') ) {

    function create_ingredients_nonhierarchical_taxonomy() {
 
        // Labels part for the GUI
     
        $labels = array (
            'name'                       => _x( 'Ingredients', 'taxonomy general name', 'epicdrop-extensions' ),
            'singular_name'              => _x( 'Ingredient', 'taxonomy singular name', 'epicdrop-extensions' ),
            'search_items'               => esc_html__( 'Search Ingredients', 'epicdrop-extensions' ),
            'popular_items'              => esc_html__( 'Popular Ingredients', 'epicdrop-extensions' ),
            'all_items'                  => esc_html__( 'All Ingredients', 'epicdrop-extensions' ),
            'parent_item'                => null,
            'parent_item_colon'          => null,
            'edit_item'                  => esc_html__( 'Edit Ingredient', 'epicdrop-extensions' ), 
            'update_item'                => esc_html__( 'Update Ingredient', 'epicdrop-extensions' ),
            'add_new_item'               => esc_html__( 'Add New Ingredient', 'epicdrop-extensions' ),
            'new_item_name'              => esc_html__( 'New Ingredient Name', 'epicdrop-extensions' ),
            'separate_items_with_commas' => esc_html__( 'Separate ingredient with commas', 'epicdrop-extensions' ),
            'add_or_remove_items'        => esc_html__( 'Add or remove ingredient', 'epicdrop-extensions' ),
            'choose_from_most_used'      => esc_html__( 'Choose from the most used ingredient', 'epicdrop-extensions' ),
            'menu_name'                  => esc_html__( 'Ingredients', 'epicdrop-extensions' ),
        ); 
     
        // Now register the non-hierarchical taxonomy like tag
     
        register_taxonomy('ingredient','post',array (
            'hierarchical'          => false,
            'labels'                => $labels,
            'show_ui'               => true,
            'show_in_rest'          => true,
            'show_admin_column'     => true,
            'update_count_callback' => '_update_post_term_count',
            'query_var'             => true,
            'rewrite'               => array( 'slug' => 'ingredient' ),
        ) );

    }
}