<?php
/**
 * Coming Soon Metabox
 *
 * Displays the coming soon meta box, tabbed, with several panels covering price, stock etc.
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * EpicDrop_Meta_Box_Coming_Soon Class.
 */
class EpicDrop_Meta_Box_Coming_Soon {

	/**
	 * Output the metabox.
	 *
	 * @param WP_Post $post
	 */

	public static function output( $post ) {

        global $post, $thepostid;

        wp_nonce_field( 'epicdrop_save_data', 'epicdrop_meta_nonce' );

        $thepostid      = $post->ID;

        $template_file  = get_post_meta( $thepostid, '_wp_page_template', true );

        if ( $template_file !== 'template-comingsoon.php' ) {
            return;
        }


        self::output_coming_soon( $post );
    }

    private static function output_coming_soon( $post ) {

    	if ( ! function_exists( 'epicdrop_get_coming_soon_meta' ) ) {
            return;
        }

        $ar_coming_soon_options = epicdrop_get_coming_soon_meta();

        $static_contents = function_exists( 'epicdrop_static_content_options' ) ? epicdrop_static_content_options() : [];

        $clean_meta_data = get_post_meta( $post->ID, '_ar_coming_soon_options', true );
        $ar_coming_soon_options = maybe_unserialize( $clean_meta_data );


        ?><div class="epicdrop-options">

                <?php

                epicdrop_wp_text_input( array(
	                'id'            => 'ar_coming_soon_options_title',
	                'name'          => 'ar_coming_soon_options[title]',
	                'label'         => esc_html__( 'Coming Soon Title', 'epicdrop-extensions' ),
	                'value'         => isset( $ar_coming_soon_options['title'] ) ? $ar_coming_soon_options['title'] : wp_kses_post( __( 'Coming Soon...', 'epicdrop-extensions' ) ),

	            ) ); 

                epicdrop_wp_textarea_input( array(
                    'id'            => 'ar_coming_soon_options_subtitle',
                    'name'          => 'ar_coming_soon_options[subtitle]',
                    'label'         => esc_html__( 'Coming Soon Subtitle', 'epicdrop-extensions' ),
                    'value'         => isset( $ar_coming_soon_options['subtitle'] ) ? $ar_coming_soon_options['subtitle'] : wp_kses_post( __( 'We are working hard to deliver best possible experience. The website is currently under construction. <u>It goes live in:</u>', 'epicdrop-extensions' ) ),
                ) );

                epicdrop_wp_text_input( array(
                    'id'            => 'ar_coming_soon_options_timer_value',
                    'label'         => esc_html__( 'Timer Value', 'epicdrop-extensions' ), 
                    'name'          => 'ar_coming_soon_options[timer_value]',
                    'value'         => isset( $ar_coming_soon_options['timer_value'] ) ? $ar_coming_soon_options['timer_value'] : '',
                ) );

                epicdrop_wp_text_input( array(
                    'id'            => 'ar_coming_soon_options_subscription_title',
                    'name'          => 'ar_coming_soon_options[subscription][title]',
                    'label'         => esc_html__( 'Subscription Title', 'epicdrop-extensions' ),
                    'value'         => isset( $ar_coming_soon_options['subscription']['title'] ) ? $ar_coming_soon_options['subscription']['title'] : wp_kses_post( __( 'Notify me!', 'epicdrop-extensions' ) ),

                ) ); 

                epicdrop_wp_textarea_input( array(
                    'id'            => 'ar_coming_soon_options_subscription_subtitle',
                    'name'          => 'ar_coming_soon_options[subscription][subtitle]',
                    'label'         => esc_html__( 'Subscription Subtitle', 'epicdrop-extensions' ),
                    'value'         => isset( $ar_coming_soon_options['subscription']['subtitle'] ) ? $ar_coming_soon_options['subscription']['subtitle'] : wp_kses_post( __( 'Let me know when your website is live and I can start order goods. Here is my email address:', 'epicdrop-extensions' ) ),
                ) );

                epicdrop_wp_text_input( array(
                    'id'            => 'ar_coming_soon_options_form_shortcode',
                    'name'          => 'ar_coming_soon_options[form][shortcode]',
                    'label'         => esc_html__( 'Subscription Form Shortcode', 'epicdrop-extensions' ),
                    'value'         => isset( $ar_coming_soon_options['form']['shortcode'] ) ? $ar_coming_soon_options['form']['shortcode'] : '',

                ) ); 



                if ( function_exists( 'epicdrop_is_mas_static_content_activated' ) && epicdrop_is_mas_static_content_activated() ) {

                    epicdrop_wp_select( array(
                        'id'            => 'ar_coming_soon_options_top_content',
                        'name'          => 'ar_coming_soon_options[top][content]',
                        'label'         => esc_html__( 'Header Static Content', 'epicdrop-extensions' ),
                        'options'       => $static_contents,
                        'value'         => isset( $ar_coming_soon_options['top']['content'] ) ? $ar_coming_soon_options['top']['content'] : '',

                    ) ); 

                    epicdrop_wp_select( array(
                        'id'            => 'ar_coming_soon_options_bottom_content',
                        'name'          => 'ar_coming_soon_options[bottom][content]',
                        'label'         => esc_html__( 'Footer Static Content', 'epicdrop-extensions' ),
                        'options'       => $static_contents,
                        'value'         => isset( $ar_coming_soon_options['bottom']['content'] ) ? $ar_coming_soon_options['bottom']['content'] : '',

                    ) );   
                }
            ?>

        </div><?php
        
    }

	public static function save( $post_id, $post ) {
        if ( isset( $_POST['ar_coming_soon_options'] ) ) {
            $clean_ar_coming_soon_options = epicdrop_clean_kses_post($_POST['ar_coming_soon_options'] );
            update_post_meta( $post_id, '_ar_coming_soon_options',  serialize( $clean_ar_coming_soon_options ) );
        }   
    }
}