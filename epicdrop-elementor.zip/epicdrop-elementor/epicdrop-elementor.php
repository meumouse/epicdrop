<?php
/**
 * Plugin Name: EpicDrop Elementor
 * Description: Extensões Elementor criadas para o tema WordPress de negócios multiuso EpicDrop
 * Plugin URI:  https://epicdrop.com.br
 * Version:     1.6.0
 * Author:      MeuMouse.com
 * Elementor tested up to: 3.6.0
 * Author URI:  https://meumouse.com
 * Text Domain: epicdrop-elementor
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'EPICDROP_ELEMENTOR_VERSION', '0.0.293' );
define( 'EPICDROP_ELEMENTOR_PREVIOUS_STABLE_VERSION', '0.0.293' );

define( 'EPICDROP_ELEMENTOR__FILE__', __FILE__ );
define( 'EPICDROP_ELEMENTOR_PLUGIN_BASE', plugin_basename( EPICDROP_ELEMENTOR__FILE__ ) );
define( 'EPICDROP_ELEMENTOR_PATH', plugin_dir_path( EPICDROP_ELEMENTOR__FILE__ ) );
define( 'EPICDROP_ELEMENTOR_ASSETS_PATH', EPICDROP_ELEMENTOR_PATH . 'assets/' );
define( 'EPICDROP_ELEMENTOR_MODULES_PATH', EPICDROP_ELEMENTOR_PATH . 'modules/' );
define( 'EPICDROP_ELEMENTOR_INCLUDES_PATH', EPICDROP_ELEMENTOR_PATH . 'includes/' );
define( 'EPICDROP_ELEMENTOR_TEMPLATES_PATH', EPICDROP_ELEMENTOR_PATH . 'templates/' );
define( 'EPICDROP_ELEMENTOR_URL', plugins_url( '/', EPICDROP_ELEMENTOR__FILE__ ) );
define( 'EPICDROP_ELEMENTOR_ASSETS_URL', EPICDROP_ELEMENTOR_URL . 'assets/' );
define( 'EPICDROP_ELEMENTOR_MODULES_URL', EPICDROP_ELEMENTOR_URL . 'modules/' );
define( 'EPICDROP_ELEMENTOR_INCLUDES_URL', EPICDROP_ELEMENTOR_URL . 'includes/' );

/**
 * Load gettext translate for our text domain.
 *
 * @since 1.0.0
 *
 * @return void
 */
function epicdrop_elementor_load_plugin() {
	load_plugin_textdomain( 'epicdrop-elementor' );

	if ( ! did_action( 'elementor/loaded' ) ) {
		add_action( 'admin_notices', 'epicdrop_elementor_fail_load' );

		return;
	}

	$elementor_version_required = '3.0.0';
	if ( ! version_compare( ELEMENTOR_VERSION, $elementor_version_required, '>=' ) ) {
		add_action( 'admin_notices', 'epicdrop_elementor_fail_load_out_of_date' );

		return;
	}

	$elementor_version_recommendation = '3.0.0';
	if ( ! version_compare( ELEMENTOR_VERSION, $elementor_version_recommendation, '>=' ) ) {
		add_action( 'admin_notices', 'epicdrop_elementor_admin_notice_upgrade_recommendation' );
	}

	require EPICDROP_ELEMENTOR_PATH . 'plugin.php';
}

add_action( 'plugins_loaded', 'epicdrop_elementor_load_plugin' );

/**
 * Show in WP Dashboard notice about the plugin is not activated.
 *
 * @since 1.0.0
 *
 * @return void
 */
function epicdrop_elementor_fail_load() {
	$screen = get_current_screen();
	if ( isset( $screen->parent_file ) && 'plugins.php' === $screen->parent_file && 'update' === $screen->id ) {
		return;
	}

	$plugin = 'elementor/elementor.php';

	if ( _is_elementor_installed() ) {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		$activation_url = wp_nonce_url( 'plugins.php?action=activate&amp;plugin=' . $plugin . '&amp;plugin_status=all&amp;paged=1&amp;s', 'activate-plugin_' . $plugin );

		$message  = '<p>' . esc_html__( 'EpicDrop Elementor is not working because you need to activate the Elementor plugin.', 'epicdrop-elementor' ) . '</p>';
		$message .= '<p>' . sprintf( '<a href="%s" class="button-primary">%s</a>', $activation_url, esc_html__( 'Activate Elementor Now', 'epicdrop-elementor' ) ) . '</p>';
	} else {
		if ( ! current_user_can( 'install_plugins' ) ) {
			return;
		}

		$install_url = wp_nonce_url( self_admin_url( 'update.php?action=install-plugin&plugin=elementor' ), 'install-plugin_elementor' );

		$message  = '<p>' . esc_html__( 'EpicDrop Elementor is not working because you need to install the Elementor plugin.', 'epicdrop-elementor' ) . '</p>';
		$message .= '<p>' . sprintf( '<a href="%s" class="button-primary">%s</a>', $install_url, esc_html__( 'Install Elementor Now', 'epicdrop-elementor' ) ) . '</p>';
	}

	echo '<div class="error"><p>' . wp_kses_post( $message ) . '</p></div>';
}

/**
 * Display error message if using out of date Elementor.
 */
function epicdrop_elementor_fail_load_out_of_date() {
	if ( ! current_user_can( 'update_plugins' ) ) {
		return;
	}

	$file_path = 'elementor/elementor.php';

	$upgrade_link = wp_nonce_url( self_admin_url( 'update.php?action=upgrade-plugin&plugin=' ) . $file_path, 'upgrade-plugin_' . $file_path );
	$message      = '<p>' . esc_html__( 'EpicDrop Elementor is not working because you are using an old version of Elementor.', 'epicdrop-elementor' ) . '</p>';
	$message     .= '<p>' . sprintf( '<a href="%s" class="button-primary">%s</a>', $upgrade_link, esc_html__( 'Update Elementor Now', 'epicdrop-elementor' ) ) . '</p>';

	echo '<div class="error">' . wp_kses_post( $message ) . '</div>';
}

/**
 * Display error message to update Elementor.
 */
function epicdrop_elementor_admin_notice_upgrade_recommendation() {
	if ( ! current_user_can( 'update_plugins' ) ) {
		return;
	}

	$file_path = 'elementor/elementor.php';

	$upgrade_link = wp_nonce_url( self_admin_url( 'update.php?action=upgrade-plugin&plugin=' ) . $file_path, 'upgrade-plugin_' . $file_path );
	$message      = '<p>' . esc_html__( 'A new version of Elementor is available. For better performance and compatibility of EpicDrop Elementor, we recommend updating to the latest version.', 'epicdrop-elementor' ) . '</p>';
	$message     .= '<p>' . sprintf( '<a href="%s" class="button-primary">%s</a>', $upgrade_link, esc_html__( 'Update Elementor Now', 'epicdrop-elementor' ) ) . '</p>';

	echo '<div class="error">' . wp_kses_post( $message ) . '</div>';
}

if ( ! function_exists( '_is_elementor_installed' ) ) {
	/**
	 * Check if Elementor is installed.
	 *
	 * @return bool
	 */
	function _is_elementor_installed() {
		$file_path         = 'elementor/elementor.php';
		$installed_plugins = get_plugins();

		return isset( $installed_plugins[ $file_path ] );
	}
}
