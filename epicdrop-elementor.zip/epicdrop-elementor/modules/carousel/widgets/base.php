<?php
namespace EpicDropElementor\Modules\Carousel\Widgets;

use Elementor\Controls_Manager;
use Elementor\Repeater;
use EpicDropElementor\Base\Base_Widget;
use Elementor\Core\Files\Assets\Files_Upload_Handler;
use Elementor\Group_Control_Image_Size;


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

abstract class Base extends Base_Widget {

	private $slide_prints_count = 0;

	public function get_script_depends() {
		return [ 'imagesloaded', 'jquery', 'tiny-slider' ];

	}

	abstract protected function add_repeater_controls( Repeater $repeater );

	abstract protected function get_repeater_defaults();

	abstract protected function print_slide( array $slide, array $settings, $element_key );


	protected function register_controls() {
		$this->start_controls_section(
			'section_slides',
			[
				'label'    => esc_html__( 'Slides', 'epicdrop-elementor' ),
				'tab'      => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$this->add_repeater_controls( $repeater );

		$this->add_control(
			'slides',
			[
				'label'     => esc_html__( 'Slides', 'epicdrop-elementor' ),
				'type'      => Controls_Manager::REPEATER,
				'fields'    => $repeater->get_controls(),
				'default'   => $this->get_repeater_defaults(),
				'separator' => 'after',
			]
		);

		$this->add_responsive_control(
			'slides_per_view',
			[
				'type'    => Controls_Manager::SELECT,
				'label'   => esc_html__( 'Slides Per View', 'epicdrop-elementor' ),
				'options' => [
					''  => __( 'Default', 'epicdrop-elementor' ),
					'1' => __( '1', 'epicdrop-elementor' ),
					'2' => __( '2', 'epicdrop-elementor' ),
					'3' => __( '3', 'epicdrop-elementor' ),
					'4' => __( '4', 'epicdrop-elementor' ),
					'5' => __( '5', 'epicdrop-elementor' ),
					'6' => __( '6', 'epicdrop-elementor' ),
				],
				'frontend_available' => true,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_additional_options',
			[
				'label' => esc_html__( 'Additional Options', 'epicdrop-elementor' ),
			]
		);

		$this->add_control(
			'controls',
			[
				'type'         => Controls_Manager::SWITCHER,
				'label'        => esc_html__( 'Arrows', 'epicdrop-elementor' ),
				'default'      => 'yes',
				'label_off'    => esc_html__( 'Hide', 'epicdrop-elementor' ),
				'label_on'     => esc_html__( 'Show', 'epicdrop-elementor' ),
				'prefix_class' => 'elementor-arrows-',
				'render_type'  => 'template',
				'frontend_available' => true,
			]
		);

		$this->add_responsive_control(
			'controls_position',
			[
				'type'    => Controls_Manager::SELECT,
				'label'   => esc_html__( 'Controls Position', 'epicdrop-elementor' ),
				'options' => [
					'cs-controls-center'  => esc_html__( 'Center', 'epicdrop-elementor' ),
					'cs-controls-left'    => esc_html__( 'Left', 'epicdrop-elementor' ),
					'cs-controls-right'   => esc_html__( 'Right', 'epicdrop-elementor' ),
					'cs-controls-inside'  => esc_html__( 'Inside', 'epicdrop-elementor' ),
					'cs-controls-outside' => esc_html__( 'Outside', 'epicdrop-elementor' ),
					'cs-controls-onhover' => esc_html__( 'On Hover', 'epicdrop-elementor' ),
					
				],
				'default'      => 'cs-controls-right',
				'condition' => [
					'controls' => 'yes',
				],
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'nav',
			[
				'type'         => Controls_Manager::SWITCHER,
				'label'        => esc_html__( 'Dots', 'epicdrop-elementor' ),
				'default'      => 'false',
				'label_off'    => esc_html__( 'Hide', 'epicdrop-elementor' ),
				'label_on'     => esc_html__( 'Show', 'epicdrop-elementor' ),
				'prefix_class' => 'elementor-pagination-',
				'render_type'  => 'template',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'nav_position',
			[
				'type'         => Controls_Manager::SWITCHER,
				'label'        => esc_html__( 'Dots Position', 'epicdrop-elementor' ),
				'default'      => 'false',
				'label_off'    => esc_html__( 'Hide', 'epicdrop-elementor' ),
				'label_on'     => esc_html__( 'Show', 'epicdrop-elementor' ),
				'prefix_class' => 'elementor-pagination-',
				'render_type'  => 'template',
				'frontend_available' => true,
				'condition' => [
					'nav' => 'yes',
				],
			]
		);

		$this->add_control(
			'nav_skin',
			[
				'type'         => Controls_Manager::SWITCHER,
				'label'        => esc_html__( 'Dots Skin', 'epicdrop-elementor' ),
				'default'      => 'false',
				'label_off'    => esc_html__( 'Hide', 'epicdrop-elementor' ),
				'label_on'     => esc_html__( 'Show', 'epicdrop-elementor' ),
				'prefix_class' => 'elementor-pagination-',
				'render_type'  => 'template',
				'frontend_available' => true,
				'condition' => [
					'nav' => 'yes',
				],
			]
		);



		$this->add_control(
			'loop',
			[
				'label'      => esc_html__( 'Infinite Loop', 'epicdrop-elementor' ),
				'type'       => Controls_Manager::SWITCHER,
				'default'    => 'yes',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label'     => esc_html__( 'Autoplay', 'epicdrop-elementor' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'no',
				'separator' => 'before',
				'frontend_available' => true,
			]
		);
		$this->add_control(
			'autoheight',
			[
				'label'     => esc_html__( 'AutoHeight', 'epicdrop-elementor' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'no',
				'separator' => 'before',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'autoplay_speed',
			[
				'label'     => esc_html__( 'Autoplay Speed', 'epicdrop-elementor' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 1500,
				'condition' => [
					'autoplay' => 'yes',
				],
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'pause_on_hover',
			[
				'label'     => esc_html__( 'Pause on Hover', 'epicdrop-elementor' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
				'condition' => [
					'autoplay' => 'yes',
				],
				'frontend_available' => true,
			]
		);

		$this->add_control(
            'image_class',
            [
               'label'        => esc_html__( 'Image Class', 'epicdrop-elementor' ),
                'type'        => Controls_Manager::TEXT,
                'title'       => esc_html__( 'Add your custom class for <img> tag  without the dot. e.g: my-class', 'epicdrop-elementor' ),
                'default'     => 'img-fluid',
                'label_block' => true,
                'description' => esc_html__( 'Additional CSS class that you want to apply to the img tag', 'epicdrop-elementor' ),
            ]
        );

        $this->add_responsive_control(
            'gutter',
            [
                'label'       => esc_html__( 'Gutter Padding', 'epicdrop-elementor' ),
                'type'        => Controls_Manager::SLIDER,
                'range'  => [
                    'px' => [
                        'min' => 10,
                        'max' => 100,
                    ],
                ],
                'devices'     => [ 'desktop', 'tablet', 'mobile' ],
                'desktop_default' => [
                    'size' => 23,
                    'unit' => 'px',
                ],
                'tablet_default' => [
                    'size' => '16',
                    'unit' => 'px',
                ],
                'mobile_default' => [
                    'size' => 16,
                    'unit' => 'px',
                ],
                'size_units' => [ 'px' ],
               
            ]
        );

		$this->end_controls_section();
	}

	protected function get_slide_image_url( $slide, array $settings ) {
		$image_url = Group_Control_Image_Size::get_attachment_image_src( $slide['image']['id'], 'image_size', $settings );

		if ( ! $image_url ) {
			$image_url = $slide['image']['url'];
		}
;
		return $image_url;
	}
}
