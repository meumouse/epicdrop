<?php
namespace EpicDropElementor\Modules\Accordion\Skins;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

use Elementor;
use Elementor\Skin_Base;
use Elementor\Icons_Manager;
use Elementor\Controls_Manager;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Typography;
use EpicDropElementor\Plugin;
use Elementor\Repeater;
use EpicDropElementor\Core\Utils as ARUtils;

class Skin_Accordion_Card extends Skin_Base {
    
     public function __construct( Elementor\Widget_Base $parent ) {
        parent::__construct( $parent );
        add_filter( 'elementor/widget/print_template', array( $this, 'skin_print_template' ), 10, 2 );
        add_action( 'elementor/element/accordion/section_title/before_section_end', [ $this, 'section_title_controls' ], 10 );
        add_action( 'elementor/element/accordion/section_toggle_style_content/after_section_end', [ $this, 'style_controls' ] , 10 );
    }

    public function get_id() {
        return 'accordion-card';
    }

    public function get_title() {
        return esc_html__( 'Card', 'epicdrop-elementor' );
    }

    public function section_title_controls( Elementor\Widget_Base $widget ) {

        $this->parent = $widget;

        $this->parent->update_control(
            'tabs', [
                'condition' => [
                    '_skin' => '',
                ],
            ]
        );
        
        $this->parent->update_control(
            'selected_icon', [
                'condition' => [
                    '_skin' => '',
                ],
            ]
        );

        $this->parent->update_control(
            'selected_active_icon', [
                'condition' => [
                    'selected_icon[value]!' => '',
                    '_skin' => '',
                ],
            ]
        );

        $this->parent->update_control(
            'title_html_tag', [
                'condition' => [
                    '_skin' => '',
                ],
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'title', [
                'label'       => esc_html__( 'Title', 'epicdrop-elementor' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'dynamic'     => [
                    'active' => true,
                ],
                'default'     => esc_html__( 'Accordion Title', 'epicdrop-elementor' ),
                'placeholder' => esc_html__( 'Accordion Title', 'epicdrop-elementor' ),
            ]
        );

        $repeater->add_control(
            'content', [
                'label'       => esc_html__( 'Content', 'epicdrop-elementor' ),
                'type'        => Controls_Manager::WYSIWYG,
                'label_block' => true,
                'dynamic'     => [
                    'active' => true,
                ],
                'default'     => esc_html__( 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga.', 'epicdrop-elementor' ),
                'placeholder' => esc_html__( 'Accordion Content', 'epicdrop-elementor' ),
            ]
        );

        $this->add_control(
            'content_settings', [
                'type'      => Controls_Manager::REPEATER,
                'fields'    => $repeater->get_controls(),
                'default'   => [
                    [
                        'title'    => esc_html__( 'How do I create a playlist?', 'epicdrop-elementor' ),
                    ],
                    [
                        'title'    => esc_html__( 'Is it only possible to shuffle play music?', 'epicdrop-elementor' ),
                    ],
                    [
                        'title'    => esc_html__( 'Where can I find Podcasts?', 'epicdrop-elementor' ),
                    ],
                    [
                        'title'    => esc_html__( 'How do I activate Data Saver mode?', 'epicdrop-elementor' ),
                    ],
                ],
                'title_field' => '{{{ title }}}',
            ]
        );

        $this->add_control(
            'enable_border',
            [
                'label' => __( 'Border', 'epicdrop-elementor' ),
                'type' => Controls_Manager::SWITCHER,
            ]
        );

        $this->add_control(
            'enable_boxshadow',
            [
                'label' => __( 'Box Shadow', 'epicdrop-elementor' ),
                'type' => Controls_Manager::SWITCHER,
                'default'    => 'yes',
            ]
        );
    }

    public function style_controls( Elementor\Widget_Base $widget ) {

        $this->parent = $widget;

        $widget->update_control( 'section_toggle_style_content', [
            'condition' => [ '_skin' => '' ]
        ] );

        $widget->update_control( 'section_title_style', [
            'condition' => [ '_skin' => '' ]
        ] );

        $widget->update_control( 'section_toggle_style_title', [
            'condition' => [ '_skin' => '' ]
        ] );

        $widget->update_control( 'section_toggle_style_icon', [
            'condition' => [ '_skin' => '' ]
        ] );

        $this->start_controls_section(
            'title_section', [
                'label' => esc_html__( 'Title', 'epicdrop-elementor' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color', [
                'label'     => esc_html__( 'Color', 'epicdrop-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .accordion-heading a.collapsed' => 'color: {{VALUE}};',
                ],
                'default' => '#4a4b65',
            ]
        );

        $this->add_control(
            'title_hover_color', [
                'label'     => esc_html__( 'Title Hover Color', 'epicdrop-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .accordion-heading a:hover, {{WRAPPER}} .accordion-heading a' => 'color: {{VALUE}};',
                ],
                'default' => '#766df4',
            ]
        );

        $this->add_control(
            'card_border_color', [
                'label'     => esc_html__( 'Card Border Color', 'epicdrop-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .accordion .card.card-active' => 'border-color: {{VALUE}} !important;',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name'     => 'title_typography',
                'selector' => '{{WRAPPER}} .accordion .accordion__title',
                'global'   => [
                    'default' => Global_Typography::TYPOGRAPHY_TEXT,
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'content_section', [
                'label' => esc_html__( 'Content', 'epicdrop-elementor' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'content_color', [
                'label'     => esc_html__( 'Color', 'epicdrop-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .accordion__content' => 'color: {{VALUE}};',
                ],
                'default' => '#737491',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name'     => 'content_typography',
                'selector' => '{{WRAPPER}} .accordion__content',
                'global'   => [
                    'default' => Global_Typography::TYPOGRAPHY_TEXT,
                ],
            ]
        );

        $this->add_control(
            'content_css', [
                'label'   => esc_html__( 'CSS Class', 'epicdrop-elementor' ),
                'type'    => Controls_Manager::TEXT,
                'title'   => esc_html__( 'Add your custom class for text without the dot. e.g: my-class', 'epicdrop-elementor' ),
                'default' => ''
            ]
        );

        $this->end_controls_section();
    }

    public function render() {     
        $widget   = $this->parent;   
        $settings = $this->parent->get_settings_for_display();
        
        $content_css = $settings[ $this->get_control_id( 'content_css' ) ];
        $widget->add_render_attribute( 'content', 'class', [
            'accordion__content',
            'card-body',
        ] );
        if ( ! empty( $content_css ) ) {
            $widget->add_render_attribute( 'content', 'class', $content_css );
        }

        $items = $settings[ $this->get_control_id( 'content_settings' ) ];
        $enable_border =  $settings[ $this->get_control_id( 'enable_border' ) ];
        $box_shadow="";
        ?>
        <div class="accordion accordion-alt" id="accordionExample">
                <?php foreach( $items as $index => $item ) :
                    $accordion_count = $index + 1;

                    if ( $settings[$this->get_control_id('enable_boxshadow' ) ] ) {
                        $box_shadow = 'box-shadow ';
                        $box_shadow .= $accordion_count === 1 ? 'card-active' : '';
                    }
                ?>
                <div class="card <?php echo esc_attr( $box_shadow ); ?><?php echo esc_attr( $enable_border !== 'yes' ? ' border-0' : '');?>">
                    <div class="card-header" id="heading<?php echo $accordion_count?>">
                        <h3 class="accordion-heading">
                            <a class="<?php if ( $accordion_count != 1 ): ?> collapsed<?php endif;?>"data-toggle="collapse" href="#collapse<?php echo $accordion_count?>" role="button" aria-expanded="false" aria-controls="collapse<?php echo $accordion_count?>">
                                <?php echo $item['title']; ?>
                                <span class="accordion-indicator"></span>
                            </a>
                        </h3>
                    </div>
                    <div class="collapse<?php if ( $accordion_count === 1 ): ?> show<?php endif;?>" id="collapse<?php echo $accordion_count?>" aria-labelledby="heading<?php echo $accordion_count?>" data-parent="#accordionExample">
                        <div <?php echo $widget->get_render_attribute_string( 'content' ); ?>>
                            <?php echo ARUtils::parse_text_editor( $item['content'], $settings ); ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <?php
    }

    public function skin_print_template( $content, $widget ) {
        if( 'accordion' == $widget->get_name() ) {
            return '';
        }
        return $content;
    }
}